﻿' =========================
' Module1.vb
' =========================
Imports ADODB

Module Module1

    Public db As New ADODB.Connection
    Public rs As New ADODB.Recordset
    Public sql As String
    Public cont As Integer
    Public resp As MsgBoxResult

    Public Sub AbrirProdutos(sender As Object, e As EventArgs)
        frm_produtos.ShowDialog()
    End Sub

    Public Sub AbrirCalculadora(sender As Object, e As EventArgs)
        Process.Start("calc.exe")
    End Sub

    Public Sub SairSistema(sender As Object, e As EventArgs)
        Application.Exit()
    End Sub

    Public Sub Produtos_Load(sender As Object, e As EventArgs)
        Conecta_banco()
        Carregar_tipo()
        Carregar_dados()
    End Sub

    Public Sub Conecta_banco()
        Try
            If db.State = 1 Then db.Close()

            db.Open("Provider=SQLOLEDB;Data Source=CSHARP\SQLEXPRESS;Initial Catalog=db_mercado;Integrated Security=SSPI;")

        Catch ex As Exception
            MsgBox("Erro ao conectar no banco: " & ex.Message)
        End Try
    End Sub

    Public Sub Carregar_tipo()

        With frm_produtos.cmb_campo.Items
            .Clear()
            .Add("codigo")
            .Add("nome")
            .Add("categoria")
            .Add("fornecedor")
        End With

        frm_produtos.cmb_campo.SelectedIndex = 1

    End Sub

    Public Sub Carregar_dados()

        Try
            sql = "SELECT * FROM tb_produtos ORDER BY nome ASC"
            rs = db.Execute(sql)

            With frm_produtos.dgv_dados

                .Rows.Clear()
                cont = 0

                Do While rs.EOF = False

                    cont += 1

                    .Rows.Add(
                        cont,
                        rs.Fields("codigo").Value,
                        rs.Fields("nome").Value,
                        rs.Fields("categoria").Value,
                        rs.Fields("preco").Value,
                        rs.Fields("quantidade").Value,
                        rs.Fields("fornecedor").Value,
                        "EDITAR",
                        "EXCLUIR"
                    )

                    rs.MoveNext()

                Loop

            End With

        Catch ex As Exception
            MsgBox("Erro ao carregar dados: " & ex.Message)
        End Try

    End Sub

    Public Sub Gravar_Click(sender As Object, e As EventArgs)

        Try
            With frm_produtos

                If .txt_codigo.Text = "" Or
                   .txt_nome.Text = "" Or
                   .txt_categoria.Text = "" Or
                   .txt_preco.Text = "" Or
                   .txt_quantidade.Text = "" Then

                    MsgBox("Preencha todos os campos obrigatórios.")
                    Exit Sub

                End If

                sql = "SELECT * FROM tb_produtos WHERE codigo='" & .txt_codigo.Text & "'"
                rs = db.Execute(sql)

                If rs.EOF = True Then

                    sql = "INSERT INTO tb_produtos (codigo,nome,categoria,preco,quantidade,fornecedor) VALUES (" &
                          "'" & .txt_codigo.Text & "'," &
                          "'" & .txt_nome.Text & "'," &
                          "'" & .txt_categoria.Text & "'," &
                          Replace(.txt_preco.Text, ",", ".") & "," &
                          .txt_quantidade.Text & "," &
                          "'" & .txt_fornecedor.Text & "')"

                    db.Execute(sql)

                    MsgBox("Produto cadastrado com sucesso!")

                Else

                    sql = "UPDATE tb_produtos SET " &
                          "nome='" & .txt_nome.Text & "'," &
                          "categoria='" & .txt_categoria.Text & "'," &
                          "preco=" & Replace(.txt_preco.Text, ",", ".") & "," &
                          "quantidade=" & .txt_quantidade.Text & "," &
                          "fornecedor='" & .txt_fornecedor.Text & "' " &
                          "WHERE codigo='" & .txt_codigo.Text & "'"

                    db.Execute(sql)

                    MsgBox("Produto atualizado com sucesso!")

                End If

            End With

            Limpar_campos()
            Carregar_dados()

        Catch ex As Exception
            MsgBox("Erro ao gravar: " & ex.Message)
        End Try

    End Sub

    Public Sub Limpar_Click(sender As Object, e As EventArgs)
        Limpar_campos()
    End Sub

    Public Sub Limpar_campos()

        With frm_produtos

            .txt_codigo.Clear()
            .txt_nome.Clear()
            .txt_categoria.Clear()
            .txt_preco.Clear()
            .txt_quantidade.Clear()
            .txt_fornecedor.Clear()

            .txt_codigo.Enabled = True
            .txt_codigo.Focus()

        End With

    End Sub

    Public Sub Buscar_TextChanged(sender As Object, e As EventArgs)

        Try

            If frm_produtos.cmb_campo.Text = "" Then Exit Sub

            sql = "SELECT * FROM tb_produtos WHERE " &
                  frm_produtos.cmb_campo.Text &
                  " LIKE '" &
                  frm_produtos.txt_buscar.Text &
                  "%' ORDER BY nome ASC"

            rs = db.Execute(sql)

            With frm_produtos.dgv_dados

                .Rows.Clear()
                cont = 0

                Do While rs.EOF = False

                    cont += 1

                    .Rows.Add(
                        cont,
                        rs.Fields("codigo").Value,
                        rs.Fields("nome").Value,
                        rs.Fields("categoria").Value,
                        rs.Fields("preco").Value,
                        rs.Fields("quantidade").Value,
                        rs.Fields("fornecedor").Value,
                        "EDITAR",
                        "EXCLUIR"
                    )

                    rs.MoveNext()

                Loop

            End With

        Catch ex As Exception
            MsgBox("Erro ao buscar: " & ex.Message)
        End Try

    End Sub

    Public Sub Grid_Click(sender As Object, e As DataGridViewCellEventArgs)

        Try

            If e.RowIndex < 0 Then Exit Sub

            Dim codigo As String =
                frm_produtos.dgv_dados.Rows(e.RowIndex).Cells(1).Value.ToString()

            If e.ColumnIndex = 7 Then
                Editar_produto(codigo)
            ElseIf e.ColumnIndex = 8 Then
                Excluir_produto(codigo)
            End If

        Catch ex As Exception
            MsgBox("Erro na grid: " & ex.Message)
        End Try

    End Sub

    Public Sub Editar_produto(codigo As String)

        Try

            sql = "SELECT * FROM tb_produtos WHERE codigo='" & codigo & "'"
            rs = db.Execute(sql)

            If rs.EOF = False Then

                With frm_produtos

                    .txt_codigo.Text = rs.Fields("codigo").Value
                    .txt_nome.Text = rs.Fields("nome").Value
                    .txt_categoria.Text = rs.Fields("categoria").Value
                    .txt_preco.Text = rs.Fields("preco").Value
                    .txt_quantidade.Text = rs.Fields("quantidade").Value
                    .txt_fornecedor.Text = rs.Fields("fornecedor").Value

                    .txt_codigo.Enabled = False

                End With

            End If

        Catch ex As Exception
            MsgBox("Erro ao editar: " & ex.Message)
        End Try

    End Sub

    Public Sub Excluir_produto(codigo As String)

        Try

            resp = MsgBox(
                "Deseja excluir o produto " & codigo & "?",
                MsgBoxStyle.YesNo + MsgBoxStyle.Question
            )

            If resp = MsgBoxResult.Yes Then

                sql = "DELETE FROM tb_produtos WHERE codigo='" & codigo & "'"
                db.Execute(sql)

                MsgBox("Produto excluído com sucesso!")

                Carregar_dados()
                Limpar_campos()

            End If

        Catch ex As Exception
            MsgBox("Erro ao excluir: " & ex.Message)
        End Try

    End Sub

End Module