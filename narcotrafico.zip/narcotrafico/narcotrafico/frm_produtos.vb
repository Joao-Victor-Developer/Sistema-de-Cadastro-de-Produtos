﻿' =========================
' frm_produtos.vb
' =========================
Public Class frm_produtos

    Private Sub frm_produtos_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Produtos_Load(sender, e)

        AddHandler btn_gravar.Click, AddressOf Gravar_Click
        AddHandler btn_limpar.Click, AddressOf Limpar_Click
        AddHandler txt_buscar.TextChanged, AddressOf Buscar_TextChanged
        AddHandler dgv_dados.CellContentClick, AddressOf Grid_Click

    End Sub

End Class