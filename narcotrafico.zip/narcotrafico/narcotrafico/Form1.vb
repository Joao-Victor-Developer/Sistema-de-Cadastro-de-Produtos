﻿' =========================
' Form1.vb
' =========================
Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        AddHandler ProdutosToolStripMenuItem.Click, AddressOf AbrirProdutos
        AddHandler CalculadoraToolStripMenuItem.Click, AddressOf AbrirCalculadora
        AddHandler SairToolStripMenuItem.Click, AddressOf SairSistema

    End Sub

End Class