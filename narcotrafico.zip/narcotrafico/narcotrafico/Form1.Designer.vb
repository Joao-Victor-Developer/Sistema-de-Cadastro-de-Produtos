﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    Private components As System.ComponentModel.IContainer

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents GerenciamentoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ProdutosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FerramentasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CalculadoraToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SistemaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SairToolStripMenuItem As ToolStripMenuItem

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        MenuStrip1 = New MenuStrip()
        GerenciamentoToolStripMenuItem = New ToolStripMenuItem()
        ProdutosToolStripMenuItem = New ToolStripMenuItem()
        FerramentasToolStripMenuItem = New ToolStripMenuItem()
        CalculadoraToolStripMenuItem = New ToolStripMenuItem()
        SistemaToolStripMenuItem = New ToolStripMenuItem()
        SairToolStripMenuItem = New ToolStripMenuItem()
        MenuStrip1.SuspendLayout()
        SuspendLayout()
        ' 
        ' MenuStrip1
        ' 
        MenuStrip1.Items.AddRange(New ToolStripItem() {GerenciamentoToolStripMenuItem, FerramentasToolStripMenuItem, SistemaToolStripMenuItem})
        MenuStrip1.Location = New Point(0, 0)
        MenuStrip1.Name = "MenuStrip1"
        MenuStrip1.Size = New Size(850, 24)
        MenuStrip1.TabIndex = 0
        ' 
        ' GerenciamentoToolStripMenuItem
        ' 
        GerenciamentoToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {ProdutosToolStripMenuItem})
        GerenciamentoToolStripMenuItem.Name = "GerenciamentoToolStripMenuItem"
        GerenciamentoToolStripMenuItem.Size = New Size(100, 20)
        GerenciamentoToolStripMenuItem.Text = "Gerenciamento"
        ' 
        ' ProdutosToolStripMenuItem
        ' 
        ProdutosToolStripMenuItem.Name = "ProdutosToolStripMenuItem"
        ProdutosToolStripMenuItem.Size = New Size(122, 22)
        ProdutosToolStripMenuItem.Text = "Produtos"
        ' 
        ' FerramentasToolStripMenuItem
        ' 
        FerramentasToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {CalculadoraToolStripMenuItem})
        FerramentasToolStripMenuItem.Name = "FerramentasToolStripMenuItem"
        FerramentasToolStripMenuItem.Size = New Size(84, 20)
        FerramentasToolStripMenuItem.Text = "Ferramentas"
        ' 
        ' CalculadoraToolStripMenuItem
        ' 
        CalculadoraToolStripMenuItem.Name = "CalculadoraToolStripMenuItem"
        CalculadoraToolStripMenuItem.Size = New Size(137, 22)
        CalculadoraToolStripMenuItem.Text = "Calculadora"
        ' 
        ' SistemaToolStripMenuItem
        ' 
        SistemaToolStripMenuItem.DropDownItems.AddRange(New ToolStripItem() {SairToolStripMenuItem})
        SistemaToolStripMenuItem.Name = "SistemaToolStripMenuItem"
        SistemaToolStripMenuItem.Size = New Size(60, 20)
        SistemaToolStripMenuItem.Text = "Sistema"
        ' 
        ' SairToolStripMenuItem
        ' 
        SairToolStripMenuItem.Name = "SairToolStripMenuItem"
        SairToolStripMenuItem.Size = New Size(93, 22)
        SairToolStripMenuItem.Text = "Sair"
        ' 
        ' Form1
        ' 
        BackColor = Color.WhiteSmoke
        ClientSize = New Size(850, 500)
        Controls.Add(MenuStrip1)
        MainMenuStrip = MenuStrip1
        Name = "Form1"
        StartPosition = FormStartPosition.CenterScreen
        Text = "MENU PRINCIPAL"
        MenuStrip1.ResumeLayout(False)
        MenuStrip1.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

End Class