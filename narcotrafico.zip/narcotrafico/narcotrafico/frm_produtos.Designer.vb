﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_produtos
    Inherits System.Windows.Forms.Form

    Private components As System.ComponentModel.IContainer

    Friend WithEvents lbl_titulo As Label
    Friend WithEvents lbl_busca As Label
    Friend WithEvents txt_buscar As TextBox
    Friend WithEvents cmb_campo As ComboBox
    Friend WithEvents lbl_codigo As Label
    Friend WithEvents txt_codigo As TextBox
    Friend WithEvents lbl_nome As Label
    Friend WithEvents txt_nome As TextBox
    Friend WithEvents lbl_categoria As Label
    Friend WithEvents txt_categoria As TextBox
    Friend WithEvents lbl_preco As Label
    Friend WithEvents txt_preco As TextBox
    Friend WithEvents lbl_quantidade As Label
    Friend WithEvents txt_quantidade As TextBox
    Friend WithEvents lbl_fornecedor As Label
    Friend WithEvents txt_fornecedor As TextBox
    Friend WithEvents btn_gravar As Button
    Friend WithEvents btn_limpar As Button
    Friend WithEvents dgv_dados As DataGridView

    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lbl_titulo = New Label()
        lbl_busca = New Label()
        txt_buscar = New TextBox()
        cmb_campo = New ComboBox()
        lbl_codigo = New Label()
        txt_codigo = New TextBox()
        lbl_nome = New Label()
        txt_nome = New TextBox()
        lbl_categoria = New Label()
        txt_categoria = New TextBox()
        lbl_preco = New Label()
        txt_preco = New TextBox()
        lbl_quantidade = New Label()
        txt_quantidade = New TextBox()
        lbl_fornecedor = New Label()
        txt_fornecedor = New TextBox()
        btn_gravar = New Button()
        btn_limpar = New Button()
        dgv_dados = New DataGridView()
        colEditar = New DataGridViewButtonColumn()
        colExcluir = New DataGridViewButtonColumn()
        DataGridViewTextBoxColumn1 = New DataGridViewTextBoxColumn()
        DataGridViewTextBoxColumn2 = New DataGridViewTextBoxColumn()
        DataGridViewTextBoxColumn3 = New DataGridViewTextBoxColumn()
        DataGridViewTextBoxColumn4 = New DataGridViewTextBoxColumn()
        DataGridViewTextBoxColumn5 = New DataGridViewTextBoxColumn()
        DataGridViewTextBoxColumn6 = New DataGridViewTextBoxColumn()
        DataGridViewTextBoxColumn7 = New DataGridViewTextBoxColumn()
        CType(dgv_dados, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lbl_titulo
        ' 
        lbl_titulo.BackColor = Color.SteelBlue
        lbl_titulo.Font = New Font("Segoe UI", 14.0F, FontStyle.Bold)
        lbl_titulo.ForeColor = Color.White
        lbl_titulo.Location = New Point(0, 0)
        lbl_titulo.Name = "lbl_titulo"
        lbl_titulo.Size = New Size(1150, 40)
        lbl_titulo.TabIndex = 0
        lbl_titulo.Text = "CADASTRO DE PRODUTOS"
        lbl_titulo.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' lbl_busca
        ' 
        lbl_busca.AutoSize = True
        lbl_busca.Location = New Point(20, 60)
        lbl_busca.Name = "lbl_busca"
        lbl_busca.Size = New Size(185, 15)
        lbl_busca.TabIndex = 1
        lbl_busca.Text = "Digite um parâmetro de pesquisa:"
        ' 
        ' txt_buscar
        ' 
        txt_buscar.Location = New Point(240, 57)
        txt_buscar.Name = "txt_buscar"
        txt_buscar.Size = New Size(250, 23)
        txt_buscar.TabIndex = 2
        ' 
        ' cmb_campo
        ' 
        cmb_campo.DropDownStyle = ComboBoxStyle.DropDownList
        cmb_campo.Location = New Point(520, 57)
        cmb_campo.Name = "cmb_campo"
        cmb_campo.Size = New Size(180, 23)
        cmb_campo.TabIndex = 3
        ' 
        ' lbl_codigo
        ' 
        lbl_codigo.AutoSize = True
        lbl_codigo.Location = New Point(20, 115)
        lbl_codigo.Name = "lbl_codigo"
        lbl_codigo.Size = New Size(129, 15)
        lbl_codigo.TabIndex = 4
        lbl_codigo.Text = "CÓDIGO DO PRODUTO"
        ' 
        ' txt_codigo
        ' 
        txt_codigo.Location = New Point(20, 140)
        txt_codigo.Name = "txt_codigo"
        txt_codigo.Size = New Size(180, 23)
        txt_codigo.TabIndex = 5
        ' 
        ' lbl_nome
        ' 
        lbl_nome.AutoSize = True
        lbl_nome.Location = New Point(230, 115)
        lbl_nome.Name = "lbl_nome"
        lbl_nome.Size = New Size(119, 15)
        lbl_nome.TabIndex = 6
        lbl_nome.Text = "NOME DO PRODUTO"
        ' 
        ' txt_nome
        ' 
        txt_nome.Location = New Point(230, 140)
        txt_nome.Name = "txt_nome"
        txt_nome.Size = New Size(360, 23)
        txt_nome.TabIndex = 7
        ' 
        ' lbl_categoria
        ' 
        lbl_categoria.AutoSize = True
        lbl_categoria.Location = New Point(20, 185)
        lbl_categoria.Name = "lbl_categoria"
        lbl_categoria.Size = New Size(70, 15)
        lbl_categoria.TabIndex = 8
        lbl_categoria.Text = "CATEGORIA"
        ' 
        ' txt_categoria
        ' 
        txt_categoria.Location = New Point(20, 210)
        txt_categoria.Name = "txt_categoria"
        txt_categoria.Size = New Size(200, 23)
        txt_categoria.TabIndex = 9
        ' 
        ' lbl_preco
        ' 
        lbl_preco.AutoSize = True
        lbl_preco.Location = New Point(250, 185)
        lbl_preco.Name = "lbl_preco"
        lbl_preco.Size = New Size(44, 15)
        lbl_preco.TabIndex = 10
        lbl_preco.Text = "PREÇO"
        ' 
        ' txt_preco
        ' 
        txt_preco.Location = New Point(250, 210)
        txt_preco.Name = "txt_preco"
        txt_preco.Size = New Size(120, 23)
        txt_preco.TabIndex = 11
        ' 
        ' lbl_quantidade
        ' 
        lbl_quantidade.AutoSize = True
        lbl_quantidade.Location = New Point(400, 185)
        lbl_quantidade.Name = "lbl_quantidade"
        lbl_quantidade.Size = New Size(81, 15)
        lbl_quantidade.TabIndex = 12
        lbl_quantidade.Text = "QUANTIDADE"
        ' 
        ' txt_quantidade
        ' 
        txt_quantidade.Location = New Point(400, 210)
        txt_quantidade.Name = "txt_quantidade"
        txt_quantidade.Size = New Size(120, 23)
        txt_quantidade.TabIndex = 13
        ' 
        ' lbl_fornecedor
        ' 
        lbl_fornecedor.AutoSize = True
        lbl_fornecedor.Location = New Point(20, 255)
        lbl_fornecedor.Name = "lbl_fornecedor"
        lbl_fornecedor.Size = New Size(82, 15)
        lbl_fornecedor.TabIndex = 14
        lbl_fornecedor.Text = "FORNECEDOR"
        ' 
        ' txt_fornecedor
        ' 
        txt_fornecedor.Location = New Point(20, 280)
        txt_fornecedor.Name = "txt_fornecedor"
        txt_fornecedor.Size = New Size(500, 23)
        txt_fornecedor.TabIndex = 15
        ' 
        ' btn_gravar
        ' 
        btn_gravar.Location = New Point(560, 210)
        btn_gravar.Name = "btn_gravar"
        btn_gravar.Size = New Size(120, 40)
        btn_gravar.TabIndex = 16
        btn_gravar.Text = "GRAVAR"
        ' 
        ' btn_limpar
        ' 
        btn_limpar.Location = New Point(700, 210)
        btn_limpar.Name = "btn_limpar"
        btn_limpar.Size = New Size(120, 40)
        btn_limpar.TabIndex = 17
        btn_limpar.Text = "LIMPAR"
        ' 
        ' dgv_dados
        ' 
        dgv_dados.AllowUserToAddRows = False
        dgv_dados.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
        dgv_dados.Columns.AddRange(New DataGridViewColumn() {DataGridViewTextBoxColumn1, DataGridViewTextBoxColumn2, DataGridViewTextBoxColumn3, DataGridViewTextBoxColumn4, DataGridViewTextBoxColumn5, DataGridViewTextBoxColumn6, DataGridViewTextBoxColumn7, colEditar, colExcluir})
        dgv_dados.Location = New Point(20, 340)
        dgv_dados.Name = "dgv_dados"
        dgv_dados.RowHeadersVisible = False
        dgv_dados.Size = New Size(1100, 280)
        dgv_dados.TabIndex = 18
        ' 
        ' colEditar
        ' 
        colEditar.HeaderText = "EDITAR"
        colEditar.Name = "colEditar"
        colEditar.Text = "EDITAR"
        colEditar.UseColumnTextForButtonValue = True
        ' 
        ' colExcluir
        ' 
        colExcluir.HeaderText = "EXCLUIR"
        colExcluir.Name = "colExcluir"
        colExcluir.Text = "EXCLUIR"
        colExcluir.UseColumnTextForButtonValue = True
        ' 
        ' DataGridViewTextBoxColumn1
        ' 
        DataGridViewTextBoxColumn1.HeaderText = "Nº"
        DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        ' 
        ' DataGridViewTextBoxColumn2
        ' 
        DataGridViewTextBoxColumn2.HeaderText = "CÓDIGO"
        DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        ' 
        ' DataGridViewTextBoxColumn3
        ' 
        DataGridViewTextBoxColumn3.HeaderText = "NOME"
        DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        ' 
        ' DataGridViewTextBoxColumn4
        ' 
        DataGridViewTextBoxColumn4.HeaderText = "CATEGORIA"
        DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        ' 
        ' DataGridViewTextBoxColumn5
        ' 
        DataGridViewTextBoxColumn5.HeaderText = "PREÇO"
        DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        ' 
        ' DataGridViewTextBoxColumn6
        ' 
        DataGridViewTextBoxColumn6.HeaderText = "QTD"
        DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        ' 
        ' DataGridViewTextBoxColumn7
        ' 
        DataGridViewTextBoxColumn7.HeaderText = "FORNECEDOR"
        DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        ' 
        ' frm_produtos
        ' 
        BackColor = Color.WhiteSmoke
        ClientSize = New Size(1150, 650)
        Controls.Add(lbl_titulo)
        Controls.Add(lbl_busca)
        Controls.Add(txt_buscar)
        Controls.Add(cmb_campo)
        Controls.Add(lbl_codigo)
        Controls.Add(txt_codigo)
        Controls.Add(lbl_nome)
        Controls.Add(txt_nome)
        Controls.Add(lbl_categoria)
        Controls.Add(txt_categoria)
        Controls.Add(lbl_preco)
        Controls.Add(txt_preco)
        Controls.Add(lbl_quantidade)
        Controls.Add(txt_quantidade)
        Controls.Add(lbl_fornecedor)
        Controls.Add(txt_fornecedor)
        Controls.Add(btn_gravar)
        Controls.Add(btn_limpar)
        Controls.Add(dgv_dados)
        Name = "frm_produtos"
        StartPosition = FormStartPosition.CenterScreen
        Text = "CADASTRO DE PRODUTOS"
        CType(dgv_dados, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents colEditar As DataGridViewButtonColumn
    Friend WithEvents colExcluir As DataGridViewButtonColumn

End Class